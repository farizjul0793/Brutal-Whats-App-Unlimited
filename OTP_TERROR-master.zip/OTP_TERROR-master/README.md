<h2 align="center">OTP TERROR</h2>
<p align="center">
  <img src="https://img.shields.io/static/v1?label=language&message=Bourne+Again+Shell&color=green&logo=nano">
  <img src="https://img.shields.io/static/v1?label=Framework&message=Bash+ID&color=green&logo=reddit"><br>
  <img src="https://img.shields.io/github/forks/Bayu12345677/OTP_TERROR?logo=git&style=social">
  <img src="https://img.shields.io/github/license/Bayu12345677/OTP_TERROR?color=green&logo=apache&style=flat-square">
</p>

<br>
Otp Terror merupakan sebuah program yang di buat dengan bash berfungsi untuk melakukan aksi teror pada target
dengan bermodalkan nomor telepon target
<br>

- Disclaimer: Hanya support nomor +62
- ## cara menginstall
\- siapkan termux versi terbaru<br>
\- setup termux anda<br>
\- install paket git<br>
\- install paket make<br>
\- install repository ini<br>
\- jalankan perintah setup dan run pada make

<details open><summary><code>Command Copy</code></summary>

```bash
pkg update
pkg upgrade
apt install curl git ruby
apt install make clang
apt install screen
apt install python
apt install python-pip mpv
pip install rich
pip install rich-cli
gem install lolcat
git clone https://github.com/Bayu12345677/OTP_TERROR.git
cd OTP_TERROR
make setup
make Run
```
</details>

- List otp
> - sms<br>
> - whatsapp<br>
